// custom data type definitions
export type ProductType = {
  productId: number;
  productName: string;
  productImage: string;
  productPrice: number;
  productStock: number;
};

export type CartElement = {
  cartProduct : ProductType;
  quantity : number;
}

export type ExchangeRate = {
  currency : String;
  rate : any;
}
