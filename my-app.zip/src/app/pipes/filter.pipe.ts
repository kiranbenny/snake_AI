import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'filter'
})
export class FilterPipe implements PipeTransform {

  transform(value: any[], selectedAlphabet: any) {
    let temp : any[] = [];
    if (selectedAlphabet){
      value.map((each)=>{
        if(each.productName.toUpperCase().startsWith(selectedAlphabet.toUpperCase()))
          temp.push(each)
      });
      return temp;
    }
      return value;
  }

}
