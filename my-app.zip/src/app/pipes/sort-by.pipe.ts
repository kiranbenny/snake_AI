import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'sortBy'
})
export class SortByPipe implements PipeTransform {
  new_arr !: any;
  transform(value: any, field: string): any[] {
    this.new_arr = [...value];
    if (field == 'Price'){
      this.new_arr.sort((a:any, b:any) => a.productPrice - b.productPrice);
    }
    if(field == 'Name'){
      this.new_arr.sort((a:any, b:any) => (a.productName > b.productName) ? 1 : ((b.productName > a.productName) ? -1 : 0))
    }
    return this.new_arr;
  }
}
