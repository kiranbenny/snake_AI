import {
  Component,
  OnInit,
  Input,
  Output,
  EventEmitter,
  OnChanges,
  SimpleChanges,
} from '@angular/core';
import { Observable } from 'rxjs';
import { CartComponent } from 'src/app/containers/cart/cart.component';
import { AddToCartService } from 'src/app/services/add-to-cart.service';
import { ConversionRateService } from 'src/app/services/conversion-rate.service';
import { CurrencyService } from 'src/app/services/currency.service';
import { ExchangeRateService } from 'src/app/services/exchange-rate.service';
import { ExchangeRate, ProductType } from 'src/types';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css'],
})
export class ProductComponent implements OnInit, OnChanges {
  // ! : to suppress variable initialization issue
  @Input() data!: ProductType;
  // @Input() rating:number=1
  @Output() btnClick = new EventEmitter();
  @Input() currencyCode = 'INR';
  @Input() selectedAlphabet !: any;

  exchangeRate : any[] = [];

  constructor(private conversionService :ConversionRateService,private exchangeService : ExchangeRateService) {
  }

  ngOnInit(): void {
    this.exchangeService.exchangeObservable.subscribe(
      (data)=>{
        this.exchangeRate = data
      },
      (err)=>{
        console.log(err);
      }
    )
    // this.currencyService.currencyObservable.subscribe(
    //   (code) => {
    //   this.currencyCode = code;
    // });
  }

  ngOnChanges(changes: SimpleChanges): void {
  }

  notifyParent(type: any) {
    // emitting/triggering a custom event
    // 0.1ms
    this.btnClick.emit({
      type,
    });
  }

  discountCalculation() {
    console.log('discount calculation', this.data.productPrice);
    return '10% off';
  }

  getRate(ele :any,rate :any){
    return Number(ele)*Number(rate);
  }

}
