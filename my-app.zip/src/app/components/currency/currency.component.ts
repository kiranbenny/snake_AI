import { Component, OnInit } from '@angular/core';
import { ConversionRateService } from 'src/app/services/conversion-rate.service';
import { CurrencyService } from 'src/app/services/currency.service';
import { ExchangeRateService } from 'src/app/services/exchange-rate.service';

@Component({
  selector: 'app-currency',
  templateUrl: './currency.component.html',
  styleUrls: ['./currency.component.css'],
})
export class CurrencyComponent implements OnInit {
  currencyCodes = ['INR', 'USD']
  // ,'EUR', 'GBP', 'CAD'];

  constructor(private currencyService: CurrencyService, private conversionService : ConversionRateService, private exchangeService : ExchangeRateService) {}


  ngOnInit(): void {
    this.currencyCodes.map((eachCurrency)=>{
      this.conversionService.initializeRates(eachCurrency).subscribe(
        (data:any)=>{
          this.exchangeService.update(data);
        },
        (err)=>{
          console.log(err);
        }
      );
    });
  }


  changeCurrency(event: Event) {
    const ele = event.target as HTMLSelectElement;
    this.currencyService.updateCurrency(ele.value);
  }
}
