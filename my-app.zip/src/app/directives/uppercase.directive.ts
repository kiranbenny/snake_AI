import { Directive, HostListener } from '@angular/core';

@Directive({
  selector: '[appUppercase]',
})
export class UppercaseDirective {
  // property binding
  // [property]="variable" : angular expects a right-hand side & right-hand side will be evaluated
  // property="data" : no evaluation will be done on the right hand side, the data will be taken as it is.
  // property : right-hand side will be considered as optional
  // <input type="text" appUppercase />
  constructor() {}

  @HostListener('keyup', ['$event'])
  changeCase(event: KeyboardEvent) {
    const ele = event.target as HTMLInputElement;
    ele.value = ele.value.toUpperCase();
  }
}
