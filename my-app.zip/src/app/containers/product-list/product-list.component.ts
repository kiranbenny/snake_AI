import { Component, OnChanges, OnDestroy, OnInit, SimpleChange, SimpleChanges } from '@angular/core';
import { Router } from '@angular/router';
import { Observable, Subscription } from 'rxjs';
import { CurrencyService } from 'src/app/services/currency.service';
import { ProductService } from 'src/app/services/product.service';
import { ProductType } from 'src/types';
import { UntilDestroy, untilDestroyed } from '@ngneat/until-destroy';
import { AddToCartService } from 'src/app/services/add-to-cart.service';
import { ConversionRateService } from 'src/app/services/conversion-rate.service';

@UntilDestroy()
@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css'],
  providers: [ProductService],
})
export class ProductListComponent implements OnInit, OnDestroy, OnChanges {
  plist: ProductType[] = [];
  alphabets = [...' abcdefghijklmnopqrstuvwxyz'];
  sortList = ["","Name","Price"];
  selectedAlphabet = '';
  sortBasedOn =' ';
  selectedCode!: string;
  currency$!: Subscription;
  code$!: Observable<string>;
  storage:any;
  p: number = 1;

  constructor(
    private currencyService: CurrencyService,
    private productService: ProductService,
    private router: Router,
    private cartService: AddToCartService,
  ) {
    this.code$ = this.currencyService.currencyObservable;
  }

  ngOnDestroy(): void {
    // this.currency$.unsubscribe();
  }

  ngOnChanges(changes: SimpleChanges): void {

  }

  ngOnInit(): void {
    // debugger;
    this.getData();
    // this.currency$ = this.currencyService.currencyObservable.subscribe(
    this.currencyService.currencyObservable
      .pipe(untilDestroyed(this))
      .subscribe((code) => {
        this.selectedCode = code;
      });
    this.storage = sessionStorage;
  }


  getData() {
    this.productService.getProducts().subscribe(
      (data) => {
        // console.log('success', data);
        // this.plist=data as ProductType[];
        this.plist = data;
      },
      (err) => {
        console.log('error', err);
      }
    );
  }

  addItem(data: any) {
    this.cartService.addToCart(data.type);
  }


  nameFilter(event: Event) {
    const ele = event.target as HTMLSelectElement;
    this.selectedAlphabet = ele.value;
  }

  sortBy(event : Event){
    const ele = event.target as HTMLSelectElement;
    this.sortBasedOn = ele.value;
  }


}
