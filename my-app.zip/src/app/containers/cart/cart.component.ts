import { Component, OnDestroy, OnInit } from '@angular/core';
import { UntilDestroy, untilDestroyed } from '@ngneat/until-destroy';
import { AddToCartService } from 'src/app/services/add-to-cart.service';
import { CurrencyService } from 'src/app/services/currency.service';
import { ExchangeRateService } from 'src/app/services/exchange-rate.service';
import { CartElement } from 'src/types';

@UntilDestroy()
@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css'],
  providers: []
})
export class CartComponent implements OnInit {
  elementsInCart !: any;
  totalCartAmount !: any;
  currencySelected!: string;
  exchangeRate : any[] = [];

  constructor(private cartService : AddToCartService ,private currencyService: CurrencyService, private exchangeService : ExchangeRateService) { }

  ngOnInit(): void {
    this.cartService.cartObservable
      .pipe(untilDestroyed(this))
      .subscribe((element) => {
        this.elementsInCart = element;
      })
    this.cartService.totalAmountObservable
      .pipe(untilDestroyed(this))
      .subscribe((amt) => {
        this.totalCartAmount = amt;
      })
    this.currencyService.currencyObservable
    .pipe(untilDestroyed(this))
      .subscribe((code) => {
        this.currencySelected = code;
      })
    this.exchangeService.exchangeObservable.subscribe(
      (data)=>{
        this.exchangeRate = data
      },
      (err)=>{
        console.log(err);
      }
    )
  }

  addToCart(event : Event, eachCartElement : CartElement){
    const ele = event.target as HTMLInputElement;
    this.cartService.addToCart(eachCartElement.cartProduct);
  }

  removeFromCart(event : Event, eachCartElement : CartElement){
    const ele = event.target as HTMLInputElement;
    this.cartService.removeFromCart(eachCartElement.cartProduct);
  }

  deleteItem(event : Event, item : CartElement){
    const ele = event.target as HTMLInputElement;
    this.cartService.deleteItem(item.cartProduct);
  }

  getRate(ele :any,rate :any){
    return Number(ele)*Number(rate);
  }

}