import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-product-detail',
  templateUrl: './product-detail.component.html',
  styleUrls: ['./product-detail.component.css'],
})
export class ProductDetailComponent implements OnInit {
  constructor(private activeRoute: ActivatedRoute) {}

  ngOnInit(): void {
    // /detail/1000 : PATH
    this.activeRoute.paramMap.subscribe((par) => {
      console.log('PID', par.get('pid'));
    });
    // /detail/1000?size=medium : QUERY
    this.activeRoute.queryParamMap.subscribe((par) => {
      if (par.has('size')) {
        console.log('SIZE', par.get('size'));
      }
    });
  }
}
