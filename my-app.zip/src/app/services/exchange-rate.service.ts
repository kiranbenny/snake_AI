import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ExchangeRateService {

  private exchangeRate : any[] = [];
  private exchangeSubject = new BehaviorSubject(this.exchangeRate);
  exchangeObservable = this.exchangeSubject.asObservable();

  constructor() { }

  update(item :any){
    this.exchangeRate.push(item);
    this.exchangeSubject.next(this.exchangeRate);
  }

}
