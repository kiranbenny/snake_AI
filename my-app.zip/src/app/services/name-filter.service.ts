import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable()
export class NameFilterService {

  private selectedAplhabet !: string ;
  private nameFilter = new BehaviorSubject(this.selectedAplhabet);
  // to get the currency code should subscribe to this observable
  nameFilterObservable = this.nameFilter.asObservable();

  constructor() {}

  updateFilter(code: string) {
    this.selectedAplhabet = code;
    // on every data change a notification needs to be provided
    this.nameFilter.next(this.selectedAplhabet);
  }
}
