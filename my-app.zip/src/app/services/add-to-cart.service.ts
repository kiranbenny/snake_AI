import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { CartElement, ProductType } from 'src/types';

@Injectable({
  providedIn: 'root'
})
export class AddToCartService {
  private inCart : any[] = [];
  private cartSubject = new BehaviorSubject(this.inCart);
  cartObservable = this.cartSubject.asObservable();

  private totalAmount : any = 0;
  private totalAmountSubject = new BehaviorSubject(this.totalAmount);
  totalAmountObservable = this.totalAmountSubject.asObservable();

  constructor() {
    let temp = localStorage.getItem('cart');
    if(temp!=null)
      this.inCart =  JSON.parse(temp);
      this.aggregatedAmount();
      this.cartSubject.next(this.inCart);
  }

  addToCart(ele: ProductType){
    let isPresent = false;
    this.inCart.map((itm)=>{
      if(itm['cartProduct']['productId'] === ele.productId){
        itm['quantity']+=1;
        isPresent = true;
      }
    })
    if(isPresent === false){
      this.inCart.push({cartProduct: ele, quantity:1});
    }
    localStorage.setItem('cart', JSON.stringify(this.inCart));
    this.aggregatedAmount();
    this.cartSubject.next(this.inCart);
  }

  removeFromCart(ele : ProductType){
    this.inCart.map((itm)=>{
      if(itm['cartProduct']['productId'] === ele.productId){
        itm['quantity']-=1;
        if (itm['quantity'] === 0)
          this.inCart = this.inCart.filter(removed => itm['cartProduct']['productId'] !== removed['cartProduct']['productId'])
        // isPresent = true;
      }
    })
    localStorage.setItem('cart', JSON.stringify(this.inCart));
    this.aggregatedAmount();
    this.cartSubject.next(this.inCart);
  }

  deleteItem(ele : ProductType){
    this.inCart = this.inCart.filter(itm => itm['cartProduct']['productId'] !== ele['productId']);
    localStorage.setItem('cart', JSON.stringify(this.inCart));
    this.aggregatedAmount();
    this.cartSubject.next(this.inCart);
  }

  aggregatedAmount(){
    this.totalAmount = this.inCart.reduce((total,currentValue)=>{
      return total + (currentValue['quantity']*currentValue['cartProduct']['productPrice'])
    },0)
    this.totalAmountSubject.next(this.totalAmount);
  }

}
