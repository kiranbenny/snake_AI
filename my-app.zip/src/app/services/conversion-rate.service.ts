import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ConversionRateService {
  constructor(private httpClient: HttpClient) {}
  initializeRates(to:any){
    const headers= new HttpHeaders().set('apikey', 'QcpykeYxGiggayfF0tdgywWpE9kbCuIK');
    const url = `https://api.apilayer.com/exchangerates_data/convert?to=${to}&from=INR&amount=1`;
    return  this.httpClient.get(url,{'headers': headers });
  }
}


