import { TestBed } from '@angular/core/testing';

import { NameFilterService } from './name-filter.service';

describe('NameFilterService', () => {
  let service: NameFilterService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(NameFilterService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
